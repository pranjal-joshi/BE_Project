from multiprocessing import Process, Pool
import sys
import time

s = time.time()
target = 99999999

def z():
	c = 0
	while c < target:
		c += 2
	print "z ovf"

def x():
	c = 0
	while c < target:
		c += 2
	print "x ovf"

def m():
        c = 0
        while c < target:
                c += 2
        print "m ovf"

def n():
        c = 0
        while c < target:
                c += 2
        print "n ovf"



#z()
#x()
a = Process(target = z)
b = Process(target = x)
c = Process(target = m)
d = Process(target = n)
#a.start()
#b.start()
#c.start()
d.start()
t = time.time() - s
print t
