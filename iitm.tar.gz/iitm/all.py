#!/usr/bin/python

import os
import time

t = time.time()
dirPath = "/root/iitm/"
z = os.listdir(dirPath)
l = len(z)

for i in range(0,l):
    s = str(z[i])
    if s.endswith('.png') or s.endswith('.bmp') or s.endswith('.jpg'):
        cmd = "python demo.py -i " + s
        os.system(cmd)
    else:
        pass

print "\nTime required for script execution: "+str(round(time.time()-t,3))+" Seconds\n"