#!/usr/bin/python

import os
import pp

ppservers = ("*",)

js = pp.Server(ppservers=ppservers,socket_timeout=720000)
js.set_ncpus(4)

def imgProc(nothing):
	dirPath = "/root/iitm/"
	z = os.listdir(dirPath)
	l = len(z)
	for i in range(0,l):
	    s = str(z[i])
	    if s.endswith('.png') or s.endswith('.bmp') or s.endswith('.jpg'):
	        cmd = "python demo.py -i " + s
	        os.system(cmd)
	    else:
	        pass

fn = js.submit(imgProc,(0,),(),("os",))
run = fn()
js.print_stats()
