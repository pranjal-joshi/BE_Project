#!/usr/bin/python

import time
import os

s = time.time()
os.system("./all.py")
print "\nTime taken: " + str(time.time() - s)+"\n"
