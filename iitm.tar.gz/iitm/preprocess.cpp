#include <iostream>
#include "opencv2/opencv.hpp"
#include "opencv2/core.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/cudaarithm.hpp"

using namespace std;
using namespace cv;
using namespace cv::cuda;

int main(int argc, char* argv[])
{

  try
  {
    cuda::DeviceInfo deviceinfo;
    cout << "GPU: "<< deviceinfo.cuda::DeviceInfo::name() << std::endl;

    Mat img = cv::imread("c1.png");
    Mat gray_img, hsv_img;

    GpuMat g_img(img);

    g_img.upload(img);
    cvtColor(img,gray_img,CV_BGR2GRAY);
    cvtColor(img,hsv_img,CV_BGR2HSV);
    imwrite("cpp_out_gray.png",gray_img);
    imwrite("cpp_out_hsv.png",hsv_img);
  }
  catch(const cv::Exception &ex)
  {
    std::cout << "Error: " << ex.what() << std::endl;
  }

  return 0;
}
